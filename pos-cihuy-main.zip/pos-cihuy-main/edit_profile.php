<?php
session_start();
include 'koneksi.php';

if(!isset($_SESSION['user'])){
    header("Location: login.php");
    exit;
}

$id = $_SESSION['user']['id'];

// Ambil data terbaru dari database
$query = mysqli_query($conn, "SELECT * FROM users WHERE id='$id'");
$user = mysqli_fetch_assoc($query);

if(isset($_POST['update'])){
    $username = $_POST['username'];
    $email = $_POST['email'];

    mysqli_query($conn, "UPDATE users SET username='$username', email='$email' WHERE id='$id'");

    // Refresh session
    $_SESSION['user']['username'] = $username;
    $_SESSION['user']['email'] = $email;

    header("Location: dashboard.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Profile</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="dashboard">

    <div class="sidebar">
        <h2>💳 POS CIHUY</h2>
        <a href="dashboard.php">🏠 Dashboard</a>
        <a href="produk.php">📦 Kelola Produk</a>
        <a href="edit_profile.php">👤 Edit Profile</a>
        <a href="logout.php">🚪 Logout</a>
    </div>

    <div class="content">

        <h1>Edit Profile</h1>

        <div class="card">
            <form method="POST">
                <input type="text" name="username" value="<?= $user['username']; ?>" required>
                <input type="email" name="email" value="<?= $user['email']; ?>" required>
                <button name="update">Update Profile</button>
            </form>
        </div>

    </div>

</div>

</body>
</html>