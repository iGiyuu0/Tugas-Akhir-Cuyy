<!DOCTYPE html>
<?php
session_start();
if(isset($_SESSION['user'])){
    header("Location: dashboard.php");
    exit;
}
?>
<html>
<head>
    <title>POS Sederhana</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="container">
    <h1>💳 POS CIHUY</h1>
    <p>Aplikasi Point Of Sale Sederhana</p>

    <a href="login.php"><button>Login</button></a>
    <a href="register.php"><button style="background:#764ba2;">Daftar</button></a>
</div>

</body>
</html>