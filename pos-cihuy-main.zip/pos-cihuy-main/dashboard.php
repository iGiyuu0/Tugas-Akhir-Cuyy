<?php
session_start();
include 'koneksi.php';

if(!isset($_SESSION['user'])){
    header("Location: login.php");
    exit;
}

$total_produk = mysqli_query($conn, "SELECT COUNT(*) as total FROM produk");
$data_produk = mysqli_fetch_assoc($total_produk);

$total_stok = mysqli_query($conn, "SELECT SUM(stok) as total_stok FROM produk");
$data_stok = mysqli_fetch_assoc($total_stok);

$chart = mysqli_query($conn, "SELECT nama_produk, stok FROM produk");
$labels = [];
$stok = [];

while($row = mysqli_fetch_assoc($chart)){
    $labels[] = $row['nama_produk'];
    $stok[] = $row['stok'];
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="dashboard">

    <div class="sidebar">
        <h2>💳 POS CIHUY</h2>
        <a href="dashboard.php">🏠 Dashboard</a>
        <a href="produk.php">📦 Kelola Produk</a>
        <a href="edit_profile.php">👤 Edit Profile</a>
        <a href="logout.php">🚪 Logout</a>
    </div>

    <div class="content">
        <h1>Selamat Datang, <?= $_SESSION['user']['username']; ?> 👋</h1>

        <div class="stats">
            <div class="stat-card">
                <h3>📦 Total Produk</h3>
                <h2><?= $data_produk['total']; ?></h2>
            </div>

            <div class="stat-card">
                <h3>💰 Total Stok</h3>
                <h2><?= $data_stok['total_stok'] ?? 0; ?></h2>
            </div>
        </div>

        <div class="card">
            <canvas id="stokChart" style="max-height:300px;"></canvas>
        </div>
    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
new Chart(document.getElementById('stokChart'), {
    type: 'bar',
    data: {
        labels: <?= json_encode($labels); ?>,
        datasets: [{
            label: 'Stok Produk',
            data: <?= json_encode($stok); ?>,
            backgroundColor: '#667eea'
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false
    }
});
</script>

</body>
</html>