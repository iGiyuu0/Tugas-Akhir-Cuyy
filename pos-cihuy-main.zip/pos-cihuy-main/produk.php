<?php
session_start();
include 'koneksi.php';

if(!isset($_SESSION['user'])){
    header("Location: login.php");
    exit;
}

// TAMBAH PRODUK
if(isset($_POST['tambah'])){
    $nama = $_POST['nama'];
    $harga = $_POST['harga'];
    $stok = $_POST['stok'];

    mysqli_query($conn, "INSERT INTO produk VALUES('', '$nama', '$harga', '$stok')");
}

// HAPUS PRODUK
if(isset($_GET['hapus'])){
    $id = $_GET['hapus'];
    mysqli_query($conn, "DELETE FROM produk WHERE id='$id'");
}

// EDIT PRODUK
if(isset($_POST['update'])){
    $id = $_POST['id'];
    $nama = $_POST['nama'];
    $harga = $_POST['harga'];
    $stok = $_POST['stok'];

    mysqli_query($conn, "UPDATE produk SET nama_produk='$nama', harga='$harga', stok='$stok' WHERE id='$id'");
}

// AMBIL DATA
$data = mysqli_query($conn, "SELECT * FROM produk");

// CEK MODE EDIT
$edit_mode = false;
if(isset($_GET['edit'])){
    $edit_mode = true;
    $id_edit = $_GET['edit'];
    $edit_data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM produk WHERE id='$id_edit'"));
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Kelola Produk</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="dashboard">

<div class="sidebar">
    <h2>💳 POS CIHUY</h2>
    <a href="dashboard.php">🏠 Dashboard</a>
    <a href="produk.php">📦 Kelola Produk</a>
    <a href="edit_profile.php">👤 Edit Profile</a>
    <a href="logout.php">🚪 Logout</a>
</div>

<div class="content">

<h1>Kelola Produk</h1>

<div class="card">
<form method="POST">
    <input type="hidden" name="id" value="<?= $edit_mode ? $edit_data['id'] : '' ?>">

    <input type="text" name="nama" placeholder="Nama Produk"
        value="<?= $edit_mode ? $edit_data['nama_produk'] : '' ?>" required>

    <input type="number" name="harga" placeholder="Harga"
        value="<?= $edit_mode ? $edit_data['harga'] : '' ?>" required>

    <input type="number" name="stok" placeholder="Stok"
        value="<?= $edit_mode ? $edit_data['stok'] : '' ?>" required>

    <?php if($edit_mode){ ?>
        <button name="update">Update Produk</button>
    <?php } else { ?>
        <button name="tambah">Tambah Produk</button>
    <?php } ?>
</form>
</div>

<br>

<div class="card">
<table class="modern-table">
<tr>
    <th>Nama</th>
    <th>Harga</th>
    <th>Stok</th>
    <th>Aksi</th>
</tr>

<?php while($row = mysqli_fetch_assoc($data)){ ?>
<tr>
    <td><?= $row['nama_produk']; ?></td>
    <td>Rp <?= number_format($row['harga']); ?></td>
    <td><?= $row['stok']; ?></td>
    <td>
        <a href="?edit=<?= $row['id']; ?>">Edit</a> |
        <a href="?hapus=<?= $row['id']; ?>" style="color:red;">Hapus</a>
    </td>
</tr>
<?php } ?>

</table>
</div>

</div>
</div>
</body>
</html>